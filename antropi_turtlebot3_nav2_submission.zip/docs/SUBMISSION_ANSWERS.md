# Draft Answers for Antropi Robotics Submission Form

Edit these answers to match what was actually completed and observed.

## 1. What was your approach?

I used the existing TurtleBot3 simulation with ROS 2 Jazzy, Gazebo, RViz2, and the Navigation2 stack. My focus was on understanding the relationship between LiDAR data, localization or SLAM, costmaps, path planning, velocity control, and the final navigation goal rather than implementing a custom navigation algorithm.

## 2. What challenges did you face?

I had to distinguish between ROS topics being present and sensor data actually being published continuously. I also inspected the velocity command pipeline and learned that Nav2 commands pass through velocity smoothing and collision monitoring. Running a separate controller on the same command topic can create competing publishers.

## 3. What did you learn?

I learned how to inspect ROS 2 nodes and topics, identify message types, trace velocity commands through the navigation stack, and diagnose sensor and launch integration issues. I also learned the importance of validating the complete path from sensor input to goal completion.

## Before submitting

Replace or qualify any statement that does not match your final run. Do not claim successful autonomous goal completion until the robot has reached a goal in the recorded demo.
