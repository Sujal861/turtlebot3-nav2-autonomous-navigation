# TurtleBot3 Autonomous Navigation with Nav2 in Gazebo

**Prepared for:** Antropi Robotics — Robotics Software Intern Assignment  
**Platform:** TurtleBot3 Burger  
**Software:** ROS 2 Jazzy, Gazebo, Navigation2 (Nav2), RViz2

## 1. Objective

Set up a TurtleBot3 robot in Gazebo with ROS 2 Navigation2 and demonstrate autonomous navigation to a goal while avoiding obstacles. The assignment permits existing packages and tutorials and does not require a custom navigation algorithm.

## 2. Approach

The intended solution uses the standard TurtleBot3 simulation and Nav2 components. Gazebo provides the robot and environment; LiDAR supplies obstacle observations; SLAM or map-based localization provides the robot pose; Nav2 plans and controls motion to a selected goal; RViz is used to visualize the map and issue the goal.

## 3. System components

- **Gazebo:** simulated robot, world, physics, and sensors.
- **TurtleBot3 Burger:** mobile robot model.
- **LiDAR:** publishes `sensor_msgs/msg/LaserScan` on `/scan`.
- **SLAM/localization:** estimates the robot pose relative to the map, depending on the chosen launch setup.
- **Nav2 planner and controller:** plan and execute goal-directed motion.
- **Velocity smoother and collision monitor:** process velocity commands and provide additional motion safeguards.
- **RViz2:** visualizes robot pose, map, costmaps, planned path, and navigation goal.

## 4. Development observations

The ROS 2 environment exposed `/scan`, `/odom`, `/cmd_vel_nav`, `/cmd_vel_smoothed`, and `/cmd_vel`. The observed velocity pipeline routed Nav2 commands through a velocity smoother and collision monitor.

During an early standalone-controller test, `/scan` was visible as a ROS topic, but continuous LaserScan reception was not confirmed. This is a sensor-stream validation issue to resolve before relying on the custom controller. For this assignment, the main priority is to run the standard Nav2 launch and verify goal-based navigation end to end.

## 5. Testing and results

Final results must be entered after running the complete Nav2 demonstration. At the time of writing, successful autonomous goal completion and obstacle avoidance have not been verified, so no success rate or performance figures are claimed.

Required evidence:
- Gazebo environment and robot
- RViz map and robot pose
- Goal set through Nav2
- Autonomous movement and obstacle avoidance
- Successful goal completion
- 1–2 minute screen recording

## 6. Challenges

1. Ensuring Gazebo and RViz launch together.
2. Confirming the LiDAR stream publishes continuously.
3. Understanding the Nav2 velocity command pipeline.
4. Avoiding competing velocity publishers during controller experiments.
5. Distinguishing a visible topic from a topic that is actively delivering messages.

## 7. Learnings

- ROS 2 topic inspection helps identify message types and node connections.
- Nav2 relies on consistent sensor data, transforms, localization, and costmaps.
- A custom reactive controller can conflict with Nav2 if both publish to the same command input.
- End-to-end validation and a clear demo are more important than claiming untested features.

## 8. Conclusion

The project is structured around the standard Nav2 workflow requested by Antropi Robotics. The next milestone is a verified demonstration of autonomous goal navigation and obstacle avoidance, followed by a concise screen recording and completion of the submission form.
