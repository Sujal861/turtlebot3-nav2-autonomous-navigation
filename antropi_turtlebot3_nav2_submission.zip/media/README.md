# Demo media

Save the final 1–2 minute screen recording and useful screenshots here.

The video should show Gazebo and RViz, a goal selected in Nav2, autonomous robot motion, obstacle avoidance, and goal completion. Include only behaviours demonstrated by the actual run.
