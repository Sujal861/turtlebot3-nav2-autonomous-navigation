# Nav2 Demo Test Plan

Mark each test only after it has been observed.

| ID | Test | Pass criteria | Status |
|---|---|---|---|
| T1 | Gazebo starts | TurtleBot3 and environment are visible | Not verified for final run |
| T2 | RViz/Nav2 starts | Robot/map and navigation tools are visible | Not verified for final run |
| T3 | Sensor stream | `/scan` publishes continuously | Not verified |
| T4 | Localization/SLAM | Robot pose is consistent with map | Not verified |
| T5 | Goal selection | Goal is accepted by Nav2 | Not verified |
| T6 | Autonomous navigation | Robot moves without teleoperation | Not verified |
| T7 | Obstacle avoidance | Robot adjusts path/stops safely around obstacle and continues or replans | Not verified |
| T8 | Goal completion | Nav2 reports success and robot reaches goal | Not verified |
| T9 | Demo recording | 1–2 minute screen recording includes Gazebo and RViz | Not recorded |

## Recording outline (1–2 minutes)

- 0:00–0:15 — show Gazebo environment and robot.
- 0:15–0:30 — show RViz map, robot pose, and Nav2 interface.
- 0:30–0:45 — set a navigation goal in RViz.
- 0:45–1:30 — show autonomous motion and obstacle avoidance.
- 1:30–1:50 — show goal completion and a short terminal/topic view if useful.

Only include the obstacle-avoidance segment if it genuinely occurs during the recorded run.
