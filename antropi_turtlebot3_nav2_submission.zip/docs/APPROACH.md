# Approach and System Architecture

## Standard Nav2 approach

This assignment can be completed using the existing TurtleBot3 and Nav2 packages rather than implementing a custom navigation algorithm.

Typical flow:

1. Gazebo simulates the TurtleBot3 and environment.
2. LiDAR publishes sensor measurements on `/scan`.
3. SLAM or a provided map/localization setup supplies the map and robot pose.
4. Nav2's planner computes a path to the goal.
5. The controller follows the path while using local obstacle information.
6. The velocity smoother and collision monitor process velocity commands.
7. RViz displays the map, robot pose, costmaps, planned path, and goal.

## Observed ROS topic details

During development, the following topics were observed:

- `/scan` — `sensor_msgs/msg/LaserScan`
- `/cmd_vel_nav` — `geometry_msgs/msg/TwistStamped`
- `/cmd_vel_smoothed` — `geometry_msgs/msg/TwistStamped`
- `/cmd_vel` — `geometry_msgs/msg/TwistStamped`
- `/odom` and `/odom/filtered` — odometry topics

The observed velocity path was:

`Nav2 command (/cmd_vel_nav) → velocity_smoother → /cmd_vel_smoothed → collision_monitor → /cmd_vel → Gazebo bridge`

Topic names can vary with launch configuration. Verify them in the running system.

## Why not use the custom right-turn controller as the main solution?

The assignment explicitly says custom navigation algorithms are not required. A hand-written forward/right-turn controller is not a substitute for demonstrating Nav2 goal navigation. Keep the focus on standard Nav2 configuration and a reproducible demonstration.
